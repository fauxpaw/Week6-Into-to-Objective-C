//
//  AppDelegate.h
//  methodSwizzle
//
//  Created by Adam Wallraff on 7/13/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

