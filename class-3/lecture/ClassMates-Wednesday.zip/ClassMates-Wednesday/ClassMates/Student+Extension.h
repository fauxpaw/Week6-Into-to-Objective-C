//
//  Student+Extension.h
//  ClassMates
//
//  Created by Michael Babiy on 7/13/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

#import "Student.h"

@interface Student (Extension)

- (BOOL)isValid;

@end
